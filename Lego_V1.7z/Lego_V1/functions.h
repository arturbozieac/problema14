#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED

add();
init();
sort_list();
free_list();
#endif // FUNCTIONS_H_INCLUDED
